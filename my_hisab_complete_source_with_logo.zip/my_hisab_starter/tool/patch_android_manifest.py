from pathlib import Path

manifest = Path("android/app/src/main/AndroidManifest.xml")
if not manifest.exists():
    raise SystemExit(f"Android manifest not found: {manifest}")

text = manifest.read_text(encoding="utf-8")
permissions = [
    '<uses-permission android:name="android.permission.RECORD_AUDIO"/>',
    '<uses-permission android:name="android.permission.INTERNET"/>',
]
for permission in permissions:
    if permission not in text:
        text = text.replace("<application", permission + "\n    <application", 1)

queries = """    <queries>
        <intent>
            <action android:name="android.speech.RecognitionService"/>
        </intent>
    </queries>
"""
if "<queries>" not in text:
    text = text.replace("<application", queries + "    <application", 1)

manifest.write_text(text, encoding="utf-8")
print("Android speech-recognition manifest permissions checked.")
