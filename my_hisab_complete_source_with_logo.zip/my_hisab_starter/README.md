# My Hisab — Flutter starter

Phone-first personal income and expense tracker starter.

## Included
- Monthly income, expense and net balance dashboard
- Local SQLite transaction storage
- Manual income/expense entry
- Initial Hindi speech-to-text entry flow and transcript status
- Transaction history and delete action
- Separate ₹1,00,000 total-income and net-savings goal cards
- Hinglish-friendly interface
- Your My Hisab PNG logo included as an in-app asset and generated Android launcher icon
- GitHub Actions workflow to build and upload a debug APK
- Android speech-recognition manifest permission patch

## Build status
The project ZIP includes source code and the PNG logo asset; it is not a verified APK. No APK should be treated as ready until GitHub Actions completes successfully and the artifact is downloaded and installed/tested on an Android phone.

## Build using GitHub from a phone
1. Use your existing GitHub repository `nexora0015/-MY-HISAB-` (or another empty repository you own).
2. Upload all files inside this ZIP, preserving the directory structure (including the hidden `.github` folder). Include `.github/workflows/build-apk.yml` and `tool/patch_android_manifest.py`.
3. Commit the files to the `main` branch.
4. Open the repository's **Actions** tab and run **Build My Hisab APK**. If Actions are disabled, enable them.
5. Wait for the run to finish. The run must show success, including `flutter analyze`, `flutter build apk --debug`, and APK verification.
6. Download the `my-hisab-debug-apk` artifact ZIP from the successful run, extract it, and install `app-debug.apk` on Android.
7. Test sample income and expense entries before adding real records.

## What the workflow does
- Installs Java 17 and Flutter stable
- Generates the Android project files
- Adds microphone and speech-recognition manifest declarations
- Resolves Flutter dependencies
- Runs static analysis
- Builds a debug APK and verifies that it is non-empty
- Uploads the APK as a workflow artifact for 14 days

## Local build (computer)
Install Flutter and Android SDK, then run:
```bash
flutter create --platforms=android --project-name my_hisab .
python3 tool/patch_android_manifest.py
flutter pub get
flutter analyze
flutter build apk --debug
```
APK output: `build/app/outputs/flutter-apk/app-debug.apk`

## Known limitations before using for real financial records
- Voice parsing is still basic; multiple transactions in one sentence are not yet reliably split into separate entries.
- The goal value is currently held in app memory and needs persistent storage.
- Edit, search/filter, CSV export, backup/restore and delete confirmation are not implemented yet.
- Voice recognition availability and language support depend on the Android device and installed speech service.
- Uninstalling the app may remove local records. Implement and test backup/export before relying on this as the only financial record.
