import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';
import 'package:speech_to_text/speech_to_text.dart' as stt;

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('en_IN');
  await HisabStore.instance.init();
  runApp(const MyHisabApp());
}

const green = Color(0xFF16845B);
const red = Color(0xFFD64545);
const ink = Color(0xFF17211D);
const canvas = Color(0xFFF5F7F5);

class HisabEntry {
  final int? id;
  final int amountPaise;
  final String type;
  final String title;
  final String category;
  final DateTime date;

  HisabEntry({
    this.id,
    required this.amountPaise,
    required this.type,
    required this.title,
    required this.category,
    required this.date,
  });

  Map<String, Object?> toMap() => {
    'id': id,
    'amount_paise': amountPaise,
    'type': type,
    'title': title,
    'category': category,
    'date': date.toIso8601String(),
  };

  factory HisabEntry.fromMap(Map<String, Object?> m) => HisabEntry(
    id: m['id'] as int?,
    amountPaise: m['amount_paise'] as int,
    type: m['type'] as String,
    title: m['title'] as String,
    category: m['category'] as String,
    date: DateTime.parse(m['date'] as String),
  );
}

class HisabStore {
  HisabStore._();
  static final instance = HisabStore._();
  Database? _db;

  Future<void> init() async {
    final path = p.join(await getDatabasesPath(), 'my_hisab.db');
    _db = await openDatabase(path, version: 1, onCreate: (db, version) async {
      await db.execute('''
        CREATE TABLE entries (
          id INTEGER PRIMARY KEY AUTOINCREMENT,
          amount_paise INTEGER NOT NULL,
          type TEXT NOT NULL,
          title TEXT NOT NULL,
          category TEXT NOT NULL,
          date TEXT NOT NULL
        )
      ''');
    });
  }

  Future<List<HisabEntry>> all() async {
    final rows = await _db!.query('entries', orderBy: 'date DESC, id DESC');
    return rows.map(HisabEntry.fromMap).toList();
  }

  Future<void> add(HisabEntry entry) async {
    await _db!.insert('entries', entry.toMap());
  }

  Future<void> delete(int id) async {
    await _db!.delete('entries', where: 'id = ?', whereArgs: [id]);
  }
}

class MyHisabApp extends StatelessWidget {
  const MyHisabApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'My Hisab',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: canvas,
      colorScheme: ColorScheme.fromSeed(seedColor: green, brightness: Brightness.light),
      appBarTheme: const AppBarTheme(backgroundColor: canvas, foregroundColor: ink),
      cardTheme: CardThemeData(color: Colors.white, elevation: 0, margin: EdgeInsets.zero),
      inputDecorationTheme: InputDecorationTheme(
        filled: true, fillColor: Colors.white,
        border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
      ),
    ),
    home: const DashboardPage(),
  );
}

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});
  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> {
  List<HisabEntry> entries = [];
  bool loading = true;
  final currency = NumberFormat.currency(locale: 'en_IN', symbol: '₹', decimalDigits: 0);
  int tab = 0;
  DateTime month = DateTime(DateTime.now().year, DateTime.now().month);
  int goalPaise = 10000000;
  final speech = stt.SpeechToText();
  bool listening = false;
  String speechStatus = '';

  @override
  void initState() { super.initState(); _load(); }

  @override
  void dispose() { speech.stop(); super.dispose(); }

  Future<void> _load() async {
    final result = await HisabStore.instance.all();
    if (!mounted) return;
    setState(() { entries = result; loading = false; });
  }

  List<HisabEntry> get monthEntries => entries.where((e) =>
    e.date.year == month.year && e.date.month == month.month).toList();

  int get income => monthEntries.where((e) => e.type == 'income').fold(0, (s, e) => s + e.amountPaise);
  int get expenses => monthEntries.where((e) => e.type == 'expense').fold(0, (s, e) => s + e.amountPaise);
  int get net => income - expenses;
  int get lifetimeIncome => entries.where((e) => e.type == 'income').fold(0, (s, e) => s + e.amountPaise);
  int get lifetimeNet => entries.fold(0, (s, e) => s + (e.type == 'income' ? e.amountPaise : -e.amountPaise));

  String money(int paise) => currency.format(paise / 100);
  String monthName(DateTime d) => DateFormat('MMMM yyyy', 'en_IN').format(d);

  Future<void> _showAdd({String? presetType, String? voiceText}) async {
    final result = await showModalBottomSheet<HisabEntry>(
      context: context, isScrollControlled: true, backgroundColor: canvas,
      builder: (_) => AddEntrySheet(presetType: presetType, voiceText: voiceText),
    );
    if (result != null) { await HisabStore.instance.add(result); await _load(); }
  }

  Future<void> _voiceAdd() async {
    final available = await speech.initialize(
      onStatus: (s) { if (mounted) setState(() => speechStatus = s); },
      onError: (e) { if (mounted) setState(() { listening = false; speechStatus = 'Voice unavailable'; }); },
    );
    if (!available) {
      if (mounted) ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Voice recognition available nahi hai. Manual entry use karein.')));
      return;
    }
    String words = '';
    setState(() { listening = true; speechStatus = 'Sun raha hoon…'; });
    await speech.listen(
      localeId: 'hi_IN',
      listenFor: const Duration(seconds: 15),
      onResult: (r) { words = r.recognizedWords; if (r.finalResult && mounted) {
        setState(() { listening = false; speechStatus = words; });
        _showAdd(voiceText: words);
      }},
    );
  }

  @override
  Widget build(BuildContext context) {
    final pages = [
      _dashboard(),
      _history(),
      _goals(),
    ];
    return Scaffold(
      appBar: AppBar(
        titleSpacing: 4,
        leadingWidth: 58,
        leading: Padding(
          padding: const EdgeInsets.fromLTRB(10, 6, 4, 6),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(13),
            child: Image.asset('assets/images/my_hisab_logo.png', fit: BoxFit.cover),
          ),
        ),
        title: const Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          Text('My Hisab', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 23)),
          Text('Apne paison ka smart hisaab', style: TextStyle(fontSize: 12, color: Colors.black54)),
        ]),
        actions: [IconButton(tooltip: 'Add income', onPressed: () => _showAdd(presetType: 'income'), icon: const Icon(Icons.add_circle_outline))],
      ),
      body: loading ? const Center(child: CircularProgressIndicator()) : IndexedStack(index: tab, children: pages),
      bottomNavigationBar: NavigationBar(
        selectedIndex: tab,
        onDestinationSelected: (i) => setState(() => tab = i),
        destinations: const [
          NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'Home'),
          NavigationDestination(icon: Icon(Icons.receipt_long_outlined), selectedIcon: Icon(Icons.receipt_long), label: 'Hisab'),
          NavigationDestination(icon: Icon(Icons.flag_outlined), selectedIcon: Icon(Icons.flag), label: 'Goals'),
        ],
      ),
      floatingActionButton: tab == 0 ? FloatingActionButton.extended(
        onPressed: listening ? () async { await speech.stop(); setState(() => listening = false); } : _voiceAdd,
        icon: Icon(listening ? Icons.stop : Icons.mic),
        label: Text(listening ? 'Stop listening' : 'Bolkar add karein'),
      ) : null,
    );
  }

  Widget _dashboard() => RefreshIndicator(
    onRefresh: _load,
    child: ListView(padding: const EdgeInsets.fromLTRB(16, 4, 16, 24), children: [
      Row(children: [
        IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month - 1)), icon: const Icon(Icons.chevron_left)),
        Expanded(child: Center(child: Text(monthName(month), style: const TextStyle(fontWeight: FontWeight.w700)))),
        IconButton(onPressed: () => setState(() => month = DateTime(month.year, month.month + 1)), icon: const Icon(Icons.chevron_right)),
      ]),
      Container(
        padding: const EdgeInsets.all(20),
        decoration: BoxDecoration(color: ink, borderRadius: BorderRadius.circular(24)),
        child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
          const Text('MONTHLY NET BALANCE', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.2)),
          const SizedBox(height: 8),
          Text('${net < 0 ? '−' : ''}${money(net.abs())}', style: TextStyle(color: net < 0 ? const Color(0xFFFF8B8B) : Colors.white, fontSize: 34, fontWeight: FontWeight.w800)),
          const SizedBox(height: 5),
          Text('Income ${money(income)}  •  Expense ${money(expenses)}', style: const TextStyle(color: Colors.white70, fontSize: 12)),
        ]),
      ),
      const SizedBox(height: 14),
      Row(children: [
        Expanded(child: _summaryCard('Total income', income, green, Icons.south_west)),
        const SizedBox(width: 12),
        Expanded(child: _summaryCard('Total expense', expenses, red, Icons.north_east)),
      ]),
      if (speechStatus.isNotEmpty) ...[
        const SizedBox(height: 10),
        Container(padding: const EdgeInsets.all(12), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
          child: Row(children: [const Icon(Icons.graphic_eq, size: 18), const SizedBox(width: 8), Expanded(child: Text(speechStatus, style: const TextStyle(fontSize: 12)))])),
      ],
      const SizedBox(height: 18),
      Row(children: [
        const Expanded(child: Text('Recent transactions', style: TextStyle(fontWeight: FontWeight.w800, fontSize: 18))),
        TextButton(onPressed: () => setState(() => tab = 1), child: const Text('See all')),
      ]),
      if (monthEntries.isEmpty)
        Container(padding: const EdgeInsets.all(24), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
          child: const Column(children: [Icon(Icons.receipt_long, size: 34, color: Colors.black38), SizedBox(height: 8), Text('Abhi koi transaction nahi'), Text('Mic par tap karke ya + se add karein', style: TextStyle(color: Colors.black54, fontSize: 12))]))
      else ...monthEntries.take(6).map(_entryTile),
      const SizedBox(height: 18),
      _goalCard('Income goal', lifetimeIncome, 10000000, '₹1,00,000 total income'),
      const SizedBox(height: 10),
      _goalCard('Net savings goal', lifetimeNet, 10000000, '₹1,00,000 net savings'),
    ]),
  );

  Widget _summaryCard(String title, int value, Color color, IconData icon) => Container(
    padding: const EdgeInsets.all(15),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Icon(icon, color: color), const SizedBox(height: 10),
      Text(title, style: const TextStyle(color: Colors.black54, fontSize: 12)),
      const SizedBox(height: 4), Text(money(value), style: TextStyle(color: color, fontSize: 21, fontWeight: FontWeight.w800)),
    ]),
  );

  Widget _entryTile(HisabEntry e) => Container(
    margin: const EdgeInsets.only(bottom: 9),
    padding: const EdgeInsets.all(13),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(16)),
    child: Row(children: [
      Container(width: 42, height: 42, decoration: BoxDecoration(color: (e.type == 'income' ? green : red).withOpacity(.10), borderRadius: BorderRadius.circular(13)),
        child: Icon(e.type == 'income' ? Icons.south_west : Icons.north_east, color: e.type == 'income' ? green : red)),
      const SizedBox(width: 12),
      Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(e.title, style: const TextStyle(fontWeight: FontWeight.w700)),
        Text('${e.category} • ${DateFormat('dd MMM').format(e.date)}', style: const TextStyle(color: Colors.black54, fontSize: 11)),
      ])),
      Text('${e.type == 'income' ? '+' : '−'}${money(e.amountPaise)}', style: TextStyle(fontWeight: FontWeight.w800, color: e.type == 'income' ? green : red)),
      if (e.id != null) IconButton(tooltip: 'Delete', onPressed: () async {
        await HisabStore.instance.delete(e.id!); await _load();
      }, icon: const Icon(Icons.delete_outline, size: 19, color: Colors.black45)),
    ]),
  );

  Widget _history() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('Transaction history', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
    const SizedBox(height: 8),
    Text('All-time income: ${money(lifetimeIncome)}', style: const TextStyle(color: green, fontWeight: FontWeight.w700)),
    Text('All-time net: ${lifetimeNet < 0 ? '−' : ''}${money(lifetimeNet.abs())}', style: TextStyle(color: lifetimeNet < 0 ? red : green, fontWeight: FontWeight.w700)),
    const SizedBox(height: 16),
    if (entries.isEmpty) const Text('Entries add karne par yahan dikhengi.'),
    ...entries.map(_entryTile),
  ]);

  Widget _goalCard(String title, int current, int target, String subtitle) {
    final ratio = (current / target).clamp(0.0, 1.0);
    return Container(padding: const EdgeInsets.all(16), decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18)),
      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
        const SizedBox(height: 5), Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 12)),
        const SizedBox(height: 10),
        ClipRRect(borderRadius: BorderRadius.circular(20), child: LinearProgressIndicator(value: ratio, minHeight: 8, backgroundColor: const Color(0xFFE6EBE7), color: green)),
        const SizedBox(height: 7),
        Text('${money(current)} / ${money(target)}  •  ${(ratio * 100).toStringAsFixed(1)}%', style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w600)),
      ]),
    );
  }

  Widget _goals() => ListView(padding: const EdgeInsets.all(16), children: [
    const Text('My financial goals', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
    const SizedBox(height: 8),
    const Text('Dono goals alag track honge: total income aur net savings.', style: TextStyle(color: Colors.black54)),
    const SizedBox(height: 18),
    _goalCard('Total income goal', lifetimeIncome, goalPaise, 'Total kamai, expenses se pehle'),
    const SizedBox(height: 12),
    _goalCard('Net savings goal', lifetimeNet, goalPaise, 'Total income minus total expenses'),
    const SizedBox(height: 16),
    OutlinedButton.icon(onPressed: () async {
      final c = TextEditingController(text: (goalPaise / 100).round().toString());
      final value = await showDialog<int>(context: context, builder: (ctx) => AlertDialog(
        title: const Text('Set goal (₹)'),
        content: TextField(controller: c, keyboardType: TextInputType.number, decoration: const InputDecoration(labelText: 'Target amount')),
        actions: [TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          FilledButton(onPressed: () => Navigator.pop(ctx, int.tryParse(c.text)), child: const Text('Save'))],
      ));
      if (value != null && value > 0) setState(() => goalPaise = value * 100);
    }, icon: const Icon(Icons.edit_outlined), label: const Text('Change goal amount')),
  ]);
}

class AddEntrySheet extends StatefulWidget {
  final String? presetType;
  final String? voiceText;
  const AddEntrySheet({super.key, this.presetType, this.voiceText});
  @override
  State<AddEntrySheet> createState() => _AddEntrySheetState();
}

class _AddEntrySheetState extends State<AddEntrySheet> {
  final amount = TextEditingController();
  final title = TextEditingController();
  String type = 'expense';
  String category = 'Other';
  DateTime date = DateTime.now();
  final categories = ['Other', 'YouTube/Work', 'Business', 'Food', 'Travel', 'Shopping', 'Bills', 'Education', 'Health'];

  @override
  void initState() {
    super.initState();
    type = widget.presetType ?? 'expense';
    final text = widget.voiceText ?? '';
    final match = RegExp(r'\d+(?:[,.]\d{1,2})?').firstMatch(text.replaceAll(',', ''));
    if (match != null) amount.text = match.group(0)!.replaceAll(',', '');
    title.text = text;
    final lower = text.toLowerCase();
    if (lower.contains('kam') || lower.contains('income') || lower.contains('earned') || lower.contains('कमाए') || lower.contains('कमाई')) type = 'income';
    if (lower.contains('kharch') || lower.contains('expense') || lower.contains('spent') || lower.contains('खर्च')) type = 'expense';
  }

  @override
  void dispose() { amount.dispose(); title.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) => Padding(
    padding: EdgeInsets.only(left: 18, right: 18, top: 20, bottom: MediaQuery.of(context).viewInsets.bottom + 22),
    child: SingleChildScrollView(child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
      const Text('Add transaction', style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800)),
      const SizedBox(height: 14),
      SegmentedButton<String>(segments: const [
        ButtonSegment(value: 'income', label: Text('Income'), icon: Icon(Icons.add_circle_outline)),
        ButtonSegment(value: 'expense', label: Text('Expense'), icon: Icon(Icons.remove_circle_outline)),
      ], selected: {type}, onSelectionChanged: (v) => setState(() => type = v.first)),
      const SizedBox(height: 12),
      TextField(controller: amount, keyboardType: const TextInputType.numberWithOptions(decimal: true), decoration: const InputDecoration(labelText: 'Amount (₹)', hintText: '200')),
      const SizedBox(height: 12),
      TextField(controller: title, decoration: const InputDecoration(labelText: 'Description', hintText: 'YouTube income / food expense')),
      const SizedBox(height: 12),
      DropdownButtonFormField<String>(value: category, decoration: const InputDecoration(labelText: 'Category'),
        items: categories.map((c) => DropdownMenuItem(value: c, child: Text(c))).toList(),
        onChanged: (v) => setState(() => category = v ?? 'Other')),
      const SizedBox(height: 12),
      OutlinedButton.icon(onPressed: () async {
        final d = await showDatePicker(context: context, initialDate: date, firstDate: DateTime(2000), lastDate: DateTime(2100));
        if (d != null) setState(() => date = d);
      }, icon: const Icon(Icons.calendar_today), label: Text(DateFormat('dd MMM yyyy').format(date))),
      const SizedBox(height: 14),
      SizedBox(width: double.infinity, child: FilledButton(
        onPressed: () {
          final parsed = double.tryParse(amount.text.trim());
          if (parsed == null || parsed <= 0) {
            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Valid amount enter karein.')));
            return;
          }
          final paise = (parsed * 100).round();
          Navigator.pop(context, HisabEntry(
            amountPaise: paise, type: type, title: title.text.trim().isEmpty ? category : title.text.trim(),
            category: category, date: date,
          ));
        },
        child: const Text('Save transaction'),
      )),
    ])),
  );
}
